#include <stdio.h>

main ()
{
int k, sum;
 sum=0;
 k=5
 while(a<16)
 {
 sum=sum+k;
 printf("%k",k);
 a=a+1;
 } 
 sum=sum+k  
 printf("%d",sum)
}
