#include (studio.h)

main()
{
  int pin1,pin2;
  printf("pin1=");
  scanf("%i",&pin1);
  printf("pin2=");
  scanf("%i",&pin2=2);  
  
  if((pin1=223)&&(pin2=322))||((pin1=445)&&(pin2=554))
  {
     printf("OYKE");                       
  }  
  else
  {
     printf("OhNOOO");
  }  
}
