#include <stdio.h>
#include <time.h>
#include <stdlib.h>

main()
{     
 int mas[100][100];
 int m,n;
 printf("n=");
 scanf("%d",&n);
 
 printf("m=");
 scanf("%d",&m);
 srand(time(NULL));
 for(int j=0;j<n;j++)
 {
   for(int i=0;j<m;i++)
   {
      mas[j][i]=rand()%11+(-2); 
       
   }
 }
 for(int j=0;j<n;j++)
 {
  for(int i=0;j<m;i++)
  {
   printf("%6i",mas[j][i]);        
  }
  printf("\n\n");
 }
}
